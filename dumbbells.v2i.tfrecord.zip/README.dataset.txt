# dumbbells > 2023-06-23 1:16pm
https://universe.roboflow.com/kairos-simfg/dumbbells

Provided by a Roboflow user
License: CC BY 4.0

